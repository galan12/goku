## Goku说明

配置「初版」

```json
{
  //入站流量设置
  "inbound": {
    "protocol": "socks5",//枚举 目前变体只包含 socks5，gmess
    "listen": "127.0.0.1",//监听的本地地址
    "port": "1080",//和 tun2socks 一致
    "settings": {
      "udp": false,//udp代理 协议还没设计好
    }
  },
  //出站流量设置
  "outbound": {
    "protocol": "gmess",
    "settings": {
      //是一个服务器列表 ，未来可能增加功能
      "servers": [
        {
          "address": "download.goku1.xyz",
          "port": 443
        }
      ]
    }
  },
  //目前仅设置uuid
  "user_setting": {
    "uuid": "b9f193c8-9849-0785-5bcd-a70d208ea1a5",
  },
  //tls的主机地址
  "tls_setting": {
    "server_name": "download.goku1.xyz"
  }
}
```

ACL 「访问控制列表」文件「例子」

```plain
#模式：[white_list_mode]\[black_list_mode]\[router_mode]
[white_list_mode]
#白名单模式下 代理程序只会代理指向匹配 [proxy_list] 地址的请求，其他请求会走本地网络
#黑名单模式下 代理程序会代理所有请求，除了那些匹配 [direct_list] 地址的请求
#路由模式下 代理程序会根据设定去代理请求 （等域名正则足够充分）
#域名正则列表覆盖越多越好，可以减少本地dns解析开销。
#规则列表支持以下
#比如 10.9.0.32/16
#比如 127.0.0.1 或者 ::1
#比如 (^|\.)gmail\.com$
[direct_list]
1.0.1.0/24
1.0.2.0/23
1.0.8.0/21
1.0.32.0/19
[proxy_list]
(^|\.)zim\.vn
(^|\.)zozotown\.com
14.102.250.18
14.102.250.19
```

