### Mac 测试版

1. 配置本机socks5端口

![QQ20201013-041344@2x](assert/QQ20201013-041344@2x.png)

2. 查看本机dns配置 并配置文档config.json![WX20201022-155738@2x](/Users/mememe/桌面/mac测试版/assert/WX20201022-155738@2x.png)
3. 执行

```bash
RUST_LOG=info ./Goku
```

