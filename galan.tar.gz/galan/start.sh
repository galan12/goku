nohup ./Goku > nohup.out 2>&1 &
